<?php include 'inc/header.php'; ?>

<div class="panel panel-default">
    <div class="panel-heading">
        <h2>User Profile <span class="pull-right"><a href="index.php" class="btn btn-primary">Back</a></span></h2>
    </div>
    <div class="panel-body">
        <form action="" method="post">
            <div style="max-width:500px; margin: 0 auto;">
                <div class="form-group">
                    <label for="name">Your Name</label>
                    <input type="text"  name="name"  id="name" class="form-control" value="ArifulIslam">
                </div>
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text"  name="username"  id="username" class="form-control"  value="arifsofg">
                </div>
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="text"  name="email"  id="email" class="form-control" value="arifsofg@gmail.com">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="text"  name="password"  id="password" class="form-control" value="password">
                </div>

                <button type="submit" name="register" class="btn btn-success">Submit</button>
        </form>
    </div>
</div>
</div>


<?php include './inc/footer.php'; ?>