<?php
include 'inc/header.php';
?>

<div class="container">
    <div class="row"> 
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3>Company Name List<span class="pull-right"><strong>Welcome! </strong>

                    </span></h3>

            </div>
            <div class="panel-body">
                <table class="table  table-bordered table-responsive table-hover">
                    <tr>
                        <th width="10%">Serial</th>
                        <th width="30%">Company Name</th>
                        <th width="30%">Company Location</th>

                        <th width="30%">Action</th>

                    </tr>
                    <?php
                    $row = $user->rowCount("select * from company");
                    $itemperpage = 10;

                    $totalpage = ceil($row / $itemperpage);
                    if (isset($_GET['page']) && !empty($_GET['page'])) {
                        $page = $_GET['page'];
                    } else {
                        $page = 1;
                    }

                    $offset = ($page - 1) * $itemperpage;
                    $data = $user->pagination($offset, $itemperpage);
                    foreach ($data as $value) {
                        ?>
                        <tr>
                            <td ><?php echo $value['companyId']; ?></td>
                            <td ><?php echo $value['companyName']; ?></td>
                            <td><?php echo $value['location']; ?></td>
                            <td>
                                <a href="profile.php?id=<?php echo $value['companyId']; ?>" class="btn btn-primary">View</a>
                                <a href="profile.php?id=<?php echo $value['companyId']; ?>" class="btn btn-primary">Edit</a>
                                <a href="profile.php?id=<?php echo $value['companyId']; ?>" class="btn btn-primary">Delete</a>
                            </td>

                        </tr>
                        <?php
                    }
                    if ($page > $totalpage) {
                        echo "<td colspan='4'>No Data Found</td>";
                    }
                    ?>

                </table>
                <?php
                for ($j = 1; $j <= $totalpage; $j++) {
                    if ($j == $page) {
                        echo '<a style="font-weight:bold; font-size:19px;" href="index.php?page=' . $j . '"> ' . $j . ' </a>';
                    } else {
                        echo '<a href="index.php?page=' . $j . '"> ' . $j . ' </a>';
                    }
                }
                ?>


            </div>
        </div>


    </div>
</div>
<br/>

<?php include './inc/footer.php'; ?>