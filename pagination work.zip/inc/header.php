<?php
$filepath = realpath(dirname(__FILE__));
include_once $filepath . '/../lib/Session.php';
include_once $filepath . '/../lib/User.php';
$db = new Database();
$user = new User();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta description="">
        <title>Login Register System</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="css/main.css" rel="stylesheet" type="text/css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/main.js"></script>
        <link rel="shortcut icon" href="img/favicon.png">

    </head>
    <body>

        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.php">PHP User Management System</a>
                </div>
                <ul class="nav navbar-nav pull-right">
                    <li><a href="profile.php">Profile</a></li>
                    
                </ul>
            </div>
        </nav>