<?php
include 'inc/header.php';
?>
<?php
$user = new User();
$userRegi = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $userRegi = $user->userRegistration($_POST);
}
?>


<div class="panel panel-default">
    <div class="panel-heading">
        <h3>User Registration <span class="pull-right"><a href="index.php" class="btn btn-primary">Back</a></span></h3>
        <button class="btn btn-default" id="test-btn">Test</button>
    </div>
    <div class="panel-body">

        <form id="submit-form" method="post">
            <?php echo $userRegi; ?>
            <div style="max-width:500px; margin: 0 auto;">

                <div class="form-group">
                    <label for="name">Your Name</label>
                    <input type="text"  name="name"  id="name" class="form-control"  placeholder="Enter your name.....">
                </div>
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text"  name="username"  id="username" class="form-control"  placeholder="Enter your username.....">
                </div>
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="text"  name="email"  id="email" class="form-control"  placeholder="Enter your email.....">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password"  name="password"  id="password" class="form-control" placeholder="Enter your password.....">
                </div>

                <button type="submit" name="register" class="btn btn-success" id="submit">Submit</button>
                <span id="error-message" class="text-danger"></span>
                <span id="success-message" class="text-sucess"></span>
        </form>
        <div class="panel panel-default"  style="margin-top: 5px;"  id="panel-body-allowed-ch">
            <div class="panel-heading" id="panel-body-allowed-ch">
                <p>Allowed Characters</p>
            </div>
            <div class="panel-body" id="panel-rules">
                <ul class="list-group-item-text " id="panel-lists">
                    <li>Username must need to be more than 3 characters.</li>
                    <li>Username must contain alphanumeric characters(a-z,A-Z,_,0-9)</li>
                    <li>Email must be valid</li>
                    <li>Password must contain alphanumeric characters(a-z,A-Z,_,0-9)</li>
                    <li>Password must need to be more than 5 characters.</li>
                </ul>
            </div>
        </div>



    </div>

</div>
</div>


<?php include './inc/footer.php'; ?>